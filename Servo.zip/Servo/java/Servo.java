/*
 * Copyright (c) 2010 University of Virginia
 * All rights reserved.
 *
 */

////////////////////////////////////////////
// Servo.java				  //
// 					  //
// Created by Tamim Sookoor on 2/03/10.   //
////////////////////////////////////////////

import net.tinyos.message.*;
import net.tinyos.util.*;
import java.io.*;

/* The "Servo" command app. Sends actuation commands to the servo.
 */
public class Servo implements MessageListener {
	private MoteIF mote;

	/* Number of for loop iterations for predefined positions. */
	private static int CENTER_1 = 800;
	private static int CLOSE_1 = 1600;
	private static int OPEN_1 = 350;

	private static int CENTER_2 = 1275;
	private static int CLOSE_2 = 1275;
	private static int OPEN_2 = 200;
	

	/* Main entry point */
	private void run() {
		System.out.println("Connected");

		mote = new MoteIF(PrintStreamMessenger.err);
		System.out.println("MoteIF created");
		mote.registerListener(new ServoMsg(), this);

		// Open up standard input.
//		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
//		String cmd = null;
		
//		ServoMsg smsg = new ServoMsg();
//			smsg.set_nodeid(1);
		
		// Read the command from the command-line.
		// try {
		// 	cmd = br.readLine();
		// 	System.out.println(cmd);
		// } catch (IOException ioe) {
		// 	System.out.println("IO error trying to read a command!");
		// 	System.exit(1);
		// }
		
	}

	private void sendCmd(ServoMsg msg) {
		try {
			mote.send(MoteIF.TOS_BCAST_ADDR, msg);
			System.exit(0);
		} catch (IOException ioe) {
			System.err.println("Warning: Got IOException sending message: " + ioe);
			ioe.printStackTrace();
			System.exit(0);
		}
	}

	public synchronized void messageReceived(int dest_addr, Message msg) {
	}

	public static void main (String[] args) {
		Servo me = new Servo();
		me.run();

		ServoMsg smsg = new ServoMsg();

		if (Integer.parseInt(args[0]) == 1) {
			smsg.set_nodeid(1);
			System.out.println(args[0]);
			if (args[1].equals("center")) {
				System.out.println(CENTER_1);
				smsg.set_cmd(CENTER_1);
			}
			else if (args[1].equals("open")) {
				System.out.println(OPEN_1);
				smsg.set_cmd(OPEN_1);
			}
			else {
				System.out.println(CLOSE_1);
				smsg.set_cmd(CLOSE_1);
			}
		}
		else {
			smsg.set_nodeid(2);
			if (args[1].equals("center")) {
				System.out.println(CENTER_2);
				smsg.set_cmd(CENTER_2);
			}
			else if (args[1].equals("open")) {
				System.out.println(OPEN_2);
				smsg.set_cmd(OPEN_2);
			}
			else {
				System.out.println(CLOSE_2);
				smsg.set_cmd(CLOSE_2);
			}
		}

		me.sendCmd(smsg);
		
		//	while (true) {

			// Prompt the user to enter a command.
		//		System.out.println("Enter a command (min, center, max, exit, or number): ");
			


//			try {
//				smsg.set_cmd(Integer.parseInt(cmd));
//				me.sendCmd(smsg, "Custom");
//			}
//			catch (NumberFormatException nFE) {
//				if (cmd.equals("center")) {
//					smsg.set_cmd(CENTER);
//					me.sendCmd(smsg, "Center");
//				}
//				else if (cmd.equals("open")) {
//					smsg.set_cmd(OPEN);
//					me.sendCmd(smsg, "Open");
//				}
//				else if (cmd.equals("close")) {
//					smsg.set_cmd(CLOSE);
//					me.sendCmd(smsg, "Close");
//				}
//				else if (cmd.equals("exit"))
//					System.exit(0);
//				else
//					System.err.println("Unsupported command!");
//			}
			//	}
	}

} // End of Servo class.
