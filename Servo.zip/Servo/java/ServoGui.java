import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import net.tinyos.message.*;
import net.tinyos.util.*;
import java.io.*;

public class ServoGui extends JApplet implements MessageListener {

	private ButtonGroup g1 = new ButtonGroup();
	private ButtonGroup g2 = new ButtonGroup();

	private JRadioButton close1 = new JRadioButton("Register1 Close", false),
		center1 = new JRadioButton("Register1 Center", false),
		open1 = new JRadioButton("Register1 Open", false), 
		close2 = new JRadioButton("Register2 Close", false),
		center2 = new JRadioButton("Register2 Center", false),
		open2 = new JRadioButton("Register2 Open", false);

	private ActionListener servo1Action = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String choice = ((JRadioButton) e.getSource()).getText();
				if (choice.equals("Register1 Close")) {
					try {
						System.out.println(choice);
						Runtime rt = Runtime.getRuntime();
						Process pr = rt.exec("java Servo 1 close");
					} catch (Exception ex) {
						System.out.println(ex.toString());
						ex.printStackTrace();
					}
				} 
				else if (choice.equals("Register1 Center")) {
					try {
						System.out.println(choice);
						Runtime rt = Runtime.getRuntime();
						Process pr = rt.exec("java Servo 1 center");
					} catch (Exception ex) {
						System.out.println(ex.toString());
						ex.printStackTrace();
					}
				}
				else {
					try {
						System.out.println(choice);
						Runtime rt = Runtime.getRuntime();
						Process pr = rt.exec("java Servo 1 open");
					} catch (Exception ex) {
						System.out.println(ex.toString());
						ex.printStackTrace();
					}
				}
			}
		};

	private ActionListener servo2Action = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String choice = ((JRadioButton) e.getSource()).getText();
				if (choice.equals("Register2 Close")) {
					try {
						System.out.println(choice);
						Runtime rt = Runtime.getRuntime();
						Process pr = rt.exec("java Servo 2 close");
					} catch (Exception ex) {
						System.out.println(ex.toString());
						ex.printStackTrace();
					}
				} 
				else if (choice.equals("Register2 Center")) {
					try {
						System.out.println(choice);
						Runtime rt = Runtime.getRuntime();
						Process pr = rt.exec("java Servo 2 center");
					} catch (Exception ex) {
						System.out.println(ex.toString());
						ex.printStackTrace();
					}
				}
				else {
					try {
						System.out.println(choice);
						Runtime rt = Runtime.getRuntime();
						Process pr = rt.exec("java Servo 2 open");
					} catch (Exception ex) {
						System.out.println(ex.toString());
						ex.printStackTrace();
					}
				}
			}
		};

	public synchronized void messageReceived(int dest_addr, Message msg) {
	}

	public static void main(String[] args) {
		ServoGui me = new ServoGui();
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (Exception evt) {}
		me.run(new ServoGui(), 200, 200);
	}

	/* Main entry point. */
	public void run(JApplet applet, int width, int height) {
		JFrame frame = new JFrame("Servo");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(applet);
		applet.init();
		applet.start();
		frame.setVisible(true);
	}

	public void init() {
		close1.addActionListener(servo1Action);
		center1.addActionListener(servo1Action);
		open1.addActionListener(servo1Action);

		close2.addActionListener(servo2Action);
		center2.addActionListener(servo2Action);
		open2.addActionListener(servo2Action);

		g1.add(close1);
		g1.add(center1);
		g1.add(open1);

		Container cp = getContentPane();
		cp.setLayout(new GridLayout(2, 2, 10, 1));
		cp.add(close1);
		cp.add(close2);
//		cp.add(center1);
//		cp.add(center2);
		cp.add(open1);
		cp.add(open2);
	}
}

