README for Servo
Author/Contact: sookoor@cs.virginia.edu

Description:

Servo is a simple application that generates Pulse Width Modulation (PWM)
signals to control a servo motor. Pin-3 on the 10-pin connector of the Telosb is
used to control the servo motor. Two timers are used. The first one fires every
18 milliseconds. The other one fires once in 1 or 2 ms after the first one
depending on whether the servo should rotate clockwise or counter-clockwise.

Tools:

Known bugs/limitations:

None.
