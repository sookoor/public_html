#ifndef SERVO_H
#define SERVO_H

enum {
	AM_SERVOMSG = 6,
	TIMER_PERIOD_MILLI = 20,
	LPL_DELAY = 1000
};

typedef nx_struct ServoMsg {
	nx_uint16_t nodeid;
	nx_uint16_t cmd;
} ServoMsg;

#endif
